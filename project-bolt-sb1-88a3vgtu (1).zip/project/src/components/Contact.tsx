import React, { useState } from 'react';
import { Phone, Mail, MapPin, ArrowRight, MessageSquare } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    channel: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Send email using a service like EmailJS or your backend
      const response = await fetch('https://api.web3forms.com/submit', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          access_key: 'YOUR_WEB3FORMS_ACCESS_KEY', // Replace with your Web3Forms access key
          ...formData,
          subject: 'New Dubbing Strategy Call Request',
        }),
      });

      if (response.ok) {
        setSubmitStatus('success');
        setFormData({ name: '', email: '', channel: '', message: '' });
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData(prev => ({
      ...prev,
      [e.target.id]: e.target.value
    }));
  };

  return (
    <div className="bg-white" id="contact-section">
      {/* Hero Section */}
      <div className="bg-[#1A1A1A] py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6">
              Let's Make Your Content
              <br />
              <span className="text-[#FF3B3B]">Speak Any Language</span>
            </h1>
            <p className="text-xl text-gray-300 mb-8 max-w-3xl mx-auto">
              Ready to reach millions of new viewers? Our professional dubbing team is here to help you expand globally.
            </p>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Information */}
          <div className="space-y-8">
            <h3 className="text-3xl font-bold mb-8">Get in Touch</h3>
            
            <div className="flex items-center space-x-4 group cursor-pointer hover:transform hover:translate-x-2 transition-transform">
              <div className="bg-[#1A1A1A] w-16 h-16 rounded-2xl flex items-center justify-center group-hover:bg-[#FF3B3B] transition-colors">
                <MessageSquare className="h-8 w-8 text-[#FF3B3B] group-hover:text-white transition-colors" />
              </div>
              <div>
                <p className="font-medium text-lg">WhatsApp</p>
                <a href="https://wa.me/918840983876" className="text-[#FF3B3B] hover:text-red-600 text-lg">
                  +91 88409 83876
                </a>
              </div>
            </div>

            <div className="flex items-center space-x-4 group cursor-pointer hover:transform hover:translate-x-2 transition-transform">
              <div className="bg-[#1A1A1A] w-16 h-16 rounded-2xl flex items-center justify-center group-hover:bg-[#FF3B3B] transition-colors">
                <Mail className="h-8 w-8 text-[#FF3B3B] group-hover:text-white transition-colors" />
              </div>
              <div>
                <p className="font-medium text-lg">Email</p>
                <a href="mailto:business@rebelmedia.in" className="text-[#FF3B3B] hover:text-red-600 text-lg">
                  business@rebelmedia.in
                </a>
              </div>
            </div>

            <div className="flex items-center space-x-4 group cursor-pointer hover:transform hover:translate-x-2 transition-transform">
              <div className="bg-[#1A1A1A] w-16 h-16 rounded-2xl flex items-center justify-center group-hover:bg-[#FF3B3B] transition-colors">
                <MapPin className="h-8 w-8 text-[#FF3B3B] group-hover:text-white transition-colors" />
              </div>
              <div>
                <p className="font-medium text-lg">Location</p>
                <p className="text-gray-600 text-lg">Based in Mumbai, Dubbing for Creators Worldwide</p>
              </div>
            </div>

            {/* Quick Response Promise */}
            <div className="bg-gray-50 p-6 rounded-2xl mt-12">
              <h4 className="font-bold text-lg mb-2">Quick Response Promise</h4>
              <p className="text-gray-600">We typically respond within 2 hours during business hours (IST).</p>
            </div>
          </div>

          {/* Contact Form */}
          <form onSubmit={handleSubmit} className="bg-white p-8 rounded-2xl shadow-xl space-y-6">
            <h3 className="text-2xl font-bold mb-8">Book Your Dubbing Strategy Call</h3>
            
            <div>
              <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                Name
              </label>
              <input
                type="text"
                id="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-[#FF3B3B] focus:border-[#FF3B3B] transition-colors"
                placeholder="Your name"
              />
            </div>

            <div>
              <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                Email
              </label>
              <input
                type="email"
                id="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-[#FF3B3B] focus:border-[#FF3B3B] transition-colors"
                placeholder="your@email.com"
              />
            </div>

            <div>
              <label htmlFor="channel" className="block text-sm font-medium text-gray-700 mb-2">
                YouTube Channel URL
              </label>
              <input
                type="url"
                id="channel"
                value={formData.channel}
                onChange={handleChange}
                required
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-[#FF3B3B] focus:border-[#FF3B3B] transition-colors"
                placeholder="https://youtube.com/c/yourchannel"
              />
            </div>

            <div>
              <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                Tell us about your dubbing needs
              </label>
              <textarea
                id="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={4}
                className="w-full px-4 py-3 border border-gray-300 rounded-xl focus:ring-[#FF3B3B] focus:border-[#FF3B3B] transition-colors"
                placeholder="What languages do you want to reach? What type of content do you create?"
              ></textarea>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className={`w-full bg-[#FF3B3B] text-white px-6 py-4 rounded-xl font-medium hover:bg-red-600 transition-colors flex items-center justify-center group ${
                isSubmitting ? 'opacity-75 cursor-not-allowed' : ''
              }`}
            >
              {isSubmitting ? 'Sending...' : 'Book Your Free Dubbing Strategy Call'}
              <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </button>

            {submitStatus === 'success' && (
              <p className="text-green-600 text-center">Thank you! We'll contact you soon.</p>
            )}
            {submitStatus === 'error' && (
              <p className="text-red-600 text-center">Something went wrong. Please try again or contact us directly.</p>
            )}

            <p className="text-center text-sm text-gray-500 mt-4">
              Usually responds in 2 hours
            </p>
          </form>
        </div>
      </div>
    </div>
  );
}